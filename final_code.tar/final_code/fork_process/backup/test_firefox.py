#!/usr/bin/python
import os
import time
import base64
i=0
j=0
os.system('/usr/bin/firefox &')
time.sleep(20)
while j<27:
	os.system('/usr/bin/firefox -safe-mode -new-tab http://www.baidu.com')
	#env1=base64.b64encode(v1)
	#env2=base64.b64decode(env1)
	#print env2	
	time.sleep(1)
	j += 1 
j=0
os.system('wmctrl -c firefox')
 
