#!/usr/bin/python
import os
import time
import base64
t=0
while t < 600:
	os.system('./fork')
	#env1=base64.b64encode(v1)
	#env2=base64.b64decode(env1)
	#print env2	
	time.sleep(5)
	t += 1 
