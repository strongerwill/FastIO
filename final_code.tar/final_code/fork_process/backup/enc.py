#!/usr/bin/python
import base64
v1='mypassword'
env1=base64.b64encode(v1)
env2=base64.b64decode(env1)
