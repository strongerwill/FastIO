#!/bin/bash

for((i=0;i<50;i++))
do

	./fork


done
	

