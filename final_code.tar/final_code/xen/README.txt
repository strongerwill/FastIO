﻿1. 路径：xen\drivers\passthrough\vtd\iommu.c
   修改函数：flush_iotlb_reg()
   相关行数：#443~574
   sloc: 0

2. 路径：xen\drivers\passthrough\iommu.c
   sloc: 0
   
3. 路径：xen\arch\x86\mm.c
   相关行数：#2438~2451 #2467~2505 #2618~2647 #4420~4574  
   sloc: 45(pgd_op), 41(pmd_op), 32(pte_op), 14
   total: 132


4. 路径：xen\include\asm-x86\mm.h
   相关行数：#200~207
   sloc: 3  


5. 路径：xen\arch\x86\x86_32\entry.S
   相关行数：#705~707
   sloc: 3

6. 路径：xen\include\public\xen.h
   相关行数：#105~107 #523~544
   sloc: 21

   
7. 路径：xen\include\asm-x86\hypercall.h
   相关行数：#72~85
   sloc: 9
 
   共计：168

 

 

