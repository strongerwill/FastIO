#!/bin/bash
sudo cp /boot/serial_kernel.cfg /boot/grub/grub.cfg
