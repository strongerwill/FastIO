#!/bin/bash
sudo cp /boot/serial_xen.cfg /boot/grub/grub.cfg
